#include <bits/stdc++.h> 
#include <iostream>
#include <fstream>
#include <queue> 
#include <vector>
using namespace std;
// finding the optimal range based on cost
struct Node { 
    int index,key,weight;
	vector<int> previous;
};

class treeNode{
	public:
	Node data;
	vector<treeNode> children;
	void setParentNode(Node info){
		data = info;
	}
};
vector<int> getSmallCostRange(vector<int> range, int cost[]){
	int from = range[0],to = range[1], small = cost[from];
	vector<int> arr;
	if(from == 0){
		small = cost[1];
			for(int i =1; i<= to ; ++i){
			small = cost[i] < small ? cost[i] : small;
		}
		for(int j=1; j<= to ;++j){
			if(small == cost[j])
				arr.push_back(j);
		}
	}
	for(int i =from; i<= to ; ++i){
		small = cost[i] < small ? cost[i] : small;
	}
	for(int j=from; j<= to ;++j){
		if(small == cost[j])
			arr.push_back(j);
	}
	return arr;
}
// finding the range (from, to) based on the N, A, B
vector<int> optimalRange(int periods, int constant, int balance, int period, int lastperiodVal){
	int range = ((period +1)*constant);
	int from = constant < (range -lastperiodVal) ? constant : (range -lastperiodVal);
	int to = ((range + balance) -lastperiodVal) < ((periods*constant)-lastperiodVal) ? ((range + balance) -lastperiodVal) : ((periods*constant)-lastperiodVal);
	to	= to > 10000 ? 10000 : to;
	from = from < 0 ? 0 : from;
	vector<int> optRange;
	optRange.push_back(from);
	optRange.push_back(to);
	return optRange;
}
//handling complete logic in the following method and returns the lowest cost
int optimalChequeSolution(int periods, int constant, int balance, int cost[]){
	vector<treeNode > adjList;
	int row=balance+periods, col= periods;
	queue<treeNode> matchedVal , recentMatched;
	vector<int> sizeOfData;
	sizeOfData.push_back(0);
	//Node *root = Node(0, 0, sizeOfData, 0);
	treeNode root;
	Node node = {0, 0, 0,sizeOfData};
	int val = periods*constant;
	if(val <= balance){
		vector<int> sizeOfData;
		sizeOfData.push_back(val);
		treeNode root;
		Node node = {0, 0, cost[val],sizeOfData};
		root.setParentNode(node);
		adjList.push_back(root);
	}
	root.setParentNode(node);
	matchedVal.push(root);
	for(int t=0;t<periods;++t){
		int lastperiodVal =0, qsize = matchedVal.size();
		while(!matchedVal.empty()){
			treeNode front = matchedVal.front();
			matchedVal.pop();
			lastperiodVal = 0;
			for(int i=0;i<front.data.previous.size() ; i++){
				lastperiodVal += front.data.previous[i];
			}
			//cout<<lastperiodVal<<endl;
			vector<int> matched  = getSmallCostRange(optimalRange(periods, constant, balance, t, lastperiodVal), cost);
			for(int m=0;m<matched.size();++m){
				vector<int> _data;
				_data.assign(front.data.previous.begin(), front.data.previous.end()); 
				_data.push_back(matched[m]);
				treeNode _node;
				_node.setParentNode({front.data.index +m, matched[m], front.data.weight+cost[matched[m]],_data});
				front.children.push_back(_node);
				recentMatched.push(_node);
				if(t == periods-1){
					//cout<<_node.data.key<<endl;
					adjList.push_back(_node);
				}
			}
		}
		matchedVal = recentMatched;
		recentMatched = queue<treeNode>();
		
	}
	treeNode small = adjList[0];
	for(int i=0 ; i<adjList.size();i++){
		small = (small.data.weight > adjList[i].data.weight) ? adjList[i] : small;
	}
	if(small.data.previous.size() >= periods){
		for(int j=1; j< small.data.previous.size();j++){
			cout<<small.data.previous[j] <<" ";
		}
	}else{
		for(int j=0; j< periods;j++){
			if(j < small.data.previous.size()){
				cout<<small.data.previous[j] <<" ";
			}else{
				cout<<0<<" ";
			}
		}
	}
	cout<<endl;
	return small.data.weight;//checkLeafNodes(tempNode.children.size());
}
int main(int argc, char* argv[])
{
	ifstream in(argv[1]);
	if(!in){
		cout<<"Cannot open  input file;"<<endl;
		return -1;
	}

	ofstream out(argv[2]);
	ifstream data("cost.txt");
	if(!out){
		cout<<"Cannot open  output file;"<<endl;
		return -1;
	}
	if(!data){
		cout<<"Cannot open  cost file;"<<endl;
		return -1;
	}
	int number,periods,constant,balance;
	in>>number;
	int x,y;
	//loading cost data
	int cost[10001];
	for(int i=0; i<10000;++i){
		data>>x>>y;
		cost[x] = y;
	}
	// reading input
	while(in>>periods>>constant>>balance){
		out<<optimalChequeSolution(periods, constant, balance, cost)<<endl;
	}
	return 0;
}